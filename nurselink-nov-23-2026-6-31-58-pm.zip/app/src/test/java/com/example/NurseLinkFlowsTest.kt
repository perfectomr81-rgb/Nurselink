package com.example

import com.example.data.NurseLinkRepository
import com.example.model.AvatarStyle
import com.example.model.BookingStatus
import com.example.model.ServiceCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NurseLinkFlowsTest {

    @Test
    fun `patient booking appears in nurse bookings and updates on accept`() {
        val nurse = NurseLinkRepository.nurses.value.first()
        val service = nurse.services.first()

        val created = NurseLinkRepository.createBooking(
            nurse = nurse,
            service = service,
            patientNameAr = "فهد العتيبي",
            patientDistrictAr = "الرياض - حي الملقا",
            dateLabelAr = "غداً • الثلاثاء",
            timeSlotAr = "04:30 م",
            notesAr = "زيارة تجريبية"
        )

        assertEquals(BookingStatus.PENDING, created.status)
        assertTrue(NurseLinkRepository.bookings.value.any { it.id == created.id })

        NurseLinkRepository.updateBookingStatus(created.id, BookingStatus.CONFIRMED)
        val updated = NurseLinkRepository.bookings.value.first { it.id == created.id }
        assertEquals(BookingStatus.CONFIRMED, updated.status)
    }

    @Test
    fun `nurse can add service and create new profile`() {
        val createdProfile = NurseLinkRepository.saveOrCreateNurseProfile(
            nurseId = null,
            nameAr = "أ. طارق السبيعي",
            titleAr = "ممرض رعاية منزلية",
            specialtyAr = "تضميد الجروح",
            category = ServiceCategory.WOUND_CARE,
            cityAr = "الرياض",
            neighborhoodAr = "حي النرجس",
            experienceYears = 6,
            licenseNumber = "NL-DEMO-9991",
            bioAr = "ممرض متخصص في العناية بالجروح.",
            isAvailableToday = true,
            avatarStyle = AvatarStyle.MONOGRAM_EMERALD
        )

        NurseLinkRepository.addNurseService(
            nurseId = createdProfile.id,
            titleAr = "تغيير ضماد طبي متقدم",
            descriptionAr = "خدمة منزلية معقمة",
            category = ServiceCategory.WOUND_CARE,
            priceSar = 175,
            durationMinutes = 40
        )

        val stored = NurseLinkRepository.nurses.value.first { it.id == createdProfile.id }
        assertTrue(stored.services.any { it.titleAr == "تغيير ضماد طبي متقدم" && it.priceSar == 175 })
    }
}
