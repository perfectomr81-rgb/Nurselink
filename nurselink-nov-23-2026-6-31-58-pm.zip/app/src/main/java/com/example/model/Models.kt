package com.example.model

import androidx.annotation.DrawableRes

enum class UserRole(val titleAr: String) {
    PATIENT("مريض"),
    NURSE("ممرض")
}

enum class ServiceCategory(val labelAr: String) {
    ALL("الكل"),
    ELDERLY_CARE("رعاية كبار السن"),
    INJECTIONS_IV("حقن ومحاليل"),
    WOUND_CARE("تضميد الجروح"),
    POST_SURGERY("رعاية ما بعد العمليات"),
    HOME_CHECKUP("فحوصات منزلية")
}

enum class AvatarStyle {
    FEMALE_1,
    FEMALE_2,
    MALE_1,
    MONOGRAM_EMERALD,
    MONOGRAM_SAGE
}

data class NursingService(
    val id: String,
    val titleAr: String,
    val descriptionAr: String,
    val category: ServiceCategory,
    val priceSar: Int,
    val durationMinutes: Int,
    val isActive: Boolean = true
)

data class NurseReview(
    val id: String,
    val patientNameAr: String,
    val rating: Float,
    val commentAr: String,
    val dateLabelAr: String
)

data class NurseProfile(
    val id: String,
    val nameAr: String,
    val titleAr: String,
    val specialtyAr: String,
    val primaryCategory: ServiceCategory,
    val cityAr: String,
    val neighborhoodAr: String,
    val experienceYears: Int,
    val licenseNumber: String,
    val rating: Double,
    val reviewsCount: Int,
    val completedVisits: Int,
    val isVerified: Boolean,
    val isAvailableToday: Boolean,
    val bioAr: String,
    val languagesAr: List<String>,
    val avatarStyle: AvatarStyle,
    @DrawableRes val avatarResId: Int? = null,
    val services: List<NursingService>,
    val reviews: List<NurseReview> = emptyList()
) {
    val startingPriceSar: Int
        get() = services.filter { it.isActive }.minOfOrNull { it.priceSar } ?: 150
}

enum class BookingStatus(val labelAr: String) {
    PENDING("بانتظار الموافقة"),
    CONFIRMED("مؤكد"),
    COMPLETED("مكتمل"),
    DECLINED("مرفوض"),
    CANCELLED("ملغي")
}

data class BookingRequest(
    val id: String,
    val nurseId: String,
    val nurseNameAr: String,
    val nurseTitleAr: String,
    val patientNameAr: String,
    val patientDistrictAr: String,
    val serviceId: String,
    val serviceTitleAr: String,
    val servicePriceSar: Int,
    val homeVisitFeeSar: Int,
    val dateLabelAr: String,
    val timeSlotAr: String,
    val notesAr: String,
    val status: BookingStatus,
    val createdAtLabelAr: String
) {
    val totalPriceSar: Int
        get() = servicePriceSar + homeVisitFeeSar
}
