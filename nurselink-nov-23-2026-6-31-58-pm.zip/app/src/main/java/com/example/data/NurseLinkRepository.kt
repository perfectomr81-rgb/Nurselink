package com.example.data

import com.example.R
import com.example.model.AvatarStyle
import com.example.model.BookingRequest
import com.example.model.BookingStatus
import com.example.model.NurseProfile
import com.example.model.NurseReview
import com.example.model.NursingService
import com.example.model.ServiceCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

object NurseLinkRepository {

    private val initialNurses = listOf(
        NurseProfile(
            id = "nurse_1",
            nameAr = "أ. سارة القحطاني",
            titleAr = "أخصائية تمريض منزلي أول",
            specialtyAr = "رعاية كبار السن وما بعد العمليات",
            primaryCategory = ServiceCategory.ELDERLY_CARE,
            cityAr = "الرياض",
            neighborhoodAr = "حي الياسمين",
            experienceYears = 8,
            licenseNumber = "NL-DEMO-4821",
            rating = 4.9,
            reviewsCount = 64,
            completedVisits = 215,
            isVerified = true,
            isAvailableToday = true,
            bioAr = "ممرضة معتمدة بخبرة تتجاوز ٨ سنوات في الرعاية التمريضية المنزلية، متابعة العلامات الحيوية، وإدارة الأدوية لكبار السن بكل عناية واهتمام.",
            languagesAr = listOf("العربية", "الإنجليزية"),
            avatarStyle = AvatarStyle.FEMALE_1,
            avatarResId = R.drawable.img_nurse_female_1,
            services = listOf(
                NursingService(
                    id = "srv_101",
                    titleAr = "جلسة رعاية كبار السن الشاملة",
                    descriptionAr = "متابعة العلامات الحيوية، تنظيم الجرعات الدوائية، وتقييم الراحة العامة بالمنزل.",
                    category = ServiceCategory.ELDERLY_CARE,
                    priceSar = 180,
                    durationMinutes = 60
                ),
                NursingService(
                    id = "srv_102",
                    titleAr = "تغيير وتضميد الجروح المعقم",
                    descriptionAr = "تعقيم احترافي للجروح السطحية والعميقة وتغيير الضمادات الطبية بأدوات معقمة.",
                    category = ServiceCategory.WOUND_CARE,
                    priceSar = 140,
                    durationMinutes = 40
                ),
                NursingService(
                    id = "srv_103",
                    titleAr = "قياس السكر والضغط والمؤشرات الحيوية",
                    descriptionAr = "فحص دوري دقيق لمؤشرات الضغط والنبض والحرارة ونسبة الأكسجين.",
                    category = ServiceCategory.HOME_CHECKUP,
                    priceSar = 95,
                    durationMinutes = 25
                )
            ),
            reviews = listOf(
                NurseReview("rev_1", "أم فهد (بيانات تجريبية)", 5.0f, "تعامل راقٍ جداً ودقة في المواعيد، نشكر اهتمامها بوالدتي.", "منذ ٣ أيام"),
                NurseReview("rev_2", "خالد السبيعي (بيانات تجريبية)", 4.8f, "شرح واضح ومتابعة ممتازة بعد العملية.", "منذ أسبوع")
            )
        ),
        NurseProfile(
            id = "nurse_2",
            nameAr = "أ. أحمد الغامدي",
            titleAr = "ممرض رعاية حرجة ومنزلية",
            specialtyAr = "تركيب المحاليل الوريدية والحقن",
            primaryCategory = ServiceCategory.INJECTIONS_IV,
            cityAr = "الرياض",
            neighborhoodAr = "حي النرجس",
            experienceYears = 6,
            licenseNumber = "NL-DEMO-3194",
            rating = 4.8,
            reviewsCount = 49,
            completedVisits = 168,
            isVerified = true,
            isAvailableToday = true,
            bioAr = "أخصائي تمريض بخبرة ميدانية في أقسام الطوارئ والرعاية المنزلية، متخصص في تركيب القسطرة الوريدية وإعطاء الحقن والمحاليل بأمان.",
            languagesAr = listOf("العربية", "الإنجليزية"),
            avatarStyle = AvatarStyle.MALE_1,
            avatarResId = R.drawable.img_nurse_male_1,
            services = listOf(
                NursingService(
                    id = "srv_201",
                    titleAr = "إعطاء الحقن العضلية أو تحت الجلد",
                    descriptionAr = "إجراء آمن وسريع للحقن الموصوفة مع مراقبة فورية بعد الإجراء.",
                    category = ServiceCategory.INJECTIONS_IV,
                    priceSar = 85,
                    durationMinutes = 20
                ),
                NursingService(
                    id = "srv_202",
                    titleAr = "تركيب ومتابعة المحلول الوريدي",
                    descriptionAr = "تركيب الكانيولا الوريدية وإعطاء المحلول الموصوف بإشراف تمريضي متكامل.",
                    category = ServiceCategory.INJECTIONS_IV,
                    priceSar = 190,
                    durationMinutes = 55
                ),
                NursingService(
                    id = "srv_203",
                    titleAr = "رعاية مريض بعد الجراحة",
                    descriptionAr = "فحص موضع الجراحة وتقييم التعافي وتنسيق مواعيد العناية اليومية.",
                    category = ServiceCategory.POST_SURGERY,
                    priceSar = 220,
                    durationMinutes = 60
                )
            ),
            reviews = listOf(
                NurseReview("rev_3", "سلطان الحربي (بيانات تجريبية)", 4.9f, "يد خفيفة واحترافية عالية في تركيب المحلول.", "منذ يومين")
            )
        ),
        NurseProfile(
            id = "nurse_3",
            nameAr = "أ. نورة الدوسري",
            titleAr = "استشارية تمريض الجروح والتأهيل",
            specialtyAr = "تضميد الجروح والقدم السكري",
            primaryCategory = ServiceCategory.WOUND_CARE,
            cityAr = "جدة",
            neighborhoodAr = "حي الشاطئ",
            experienceYears = 10,
            licenseNumber = "NL-DEMO-7740",
            rating = 4.95,
            reviewsCount = 82,
            completedVisits = 310,
            isVerified = true,
            isAvailableToday = true,
            bioAr = "خبرة ١٠ سنوات في العناية المتقدمة بالجروح المزمنة وجروح العمليات والقدم السكري باستخدام أحدث البروتوكولات المعقمة.",
            languagesAr = listOf("العربية", "الإنجليزية"),
            avatarStyle = AvatarStyle.FEMALE_2,
            avatarResId = R.drawable.img_nurse_female_2,
            services = listOf(
                NursingService(
                    id = "srv_301",
                    titleAr = "عناية متقدمة بجروح القدم السكري",
                    descriptionAr = "تنظيف طبي لطيف، ضمادات متخصصة، وإرشادات وقائية للأسرة.",
                    category = ServiceCategory.WOUND_CARE,
                    priceSar = 210,
                    durationMinutes = 50
                ),
                NursingService(
                    id = "srv_302",
                    titleAr = "إزالة الغرز الجراحية بالمنزل",
                    descriptionAr = "إزالة الخيوط أو الدبابيس الجراحية بهدوء وتعقيم تام.",
                    category = ServiceCategory.POST_SURGERY,
                    priceSar = 150,
                    durationMinutes = 35
                ),
                NursingService(
                    id = "srv_303",
                    titleAr = "باقة فحص منزلي شاملة",
                    descriptionAr = "قياس العلامات الحيوية، فحص السكر التراكمي السريع، ومراجعة خطة العناية.",
                    category = ServiceCategory.HOME_CHECKUP,
                    priceSar = 135,
                    durationMinutes = 35
                )
            ),
            reviews = listOf(
                NurseReview("rev_4", "مها العتيبي (بيانات تجريبية)", 5.0f, "ممتازة للغاية وشرحت لنا طريقة العناية اليومية بوضوح.", "منذ ٤ أيام")
            )
        ),
        NurseProfile(
            id = "nurse_4",
            nameAr = "أ. عمر الزهراني",
            titleAr = "أخصائي تمريض باطني منزلي",
            specialtyAr = "الفحوصات المنزلية ورعاية كبار السن",
            primaryCategory = ServiceCategory.HOME_CHECKUP,
            cityAr = "الدمام",
            neighborhoodAr = "حي الفيصلية",
            experienceYears = 5,
            licenseNumber = "NL-DEMO-6052",
            rating = 4.7,
            reviewsCount = 34,
            completedVisits = 112,
            isVerified = true,
            isAvailableToday = false,
            bioAr = "ممرض منزلي متخصص في المتابعة الدورية لحالات الضغط والسكري وسحب العينات المخبرية المنزلية بالتنسيق مع المختبرات المعتمدة.",
            languagesAr = listOf("العربية"),
            avatarStyle = AvatarStyle.MONOGRAM_EMERALD,
            avatarResId = null,
            services = listOf(
                NursingService(
                    id = "srv_401",
                    titleAr = "سحب عينات الدم المنزلية",
                    descriptionAr = "سحب العينات المخبرية بالمنزل مع تجهيزها وفق معايير السلامة.",
                    category = ServiceCategory.HOME_CHECKUP,
                    priceSar = 110,
                    durationMinutes = 25
                ),
                NursingService(
                    id = "srv_402",
                    titleAr = "مرافقة ورعاية مسنين (٣ ساعات)",
                    descriptionAr = "رعاية تمريضية مريحة تشمل المتابعة الحيوية والمساعدة في الحركة.",
                    category = ServiceCategory.ELDERLY_CARE,
                    priceSar = 280,
                    durationMinutes = 180
                )
            ),
            reviews = listOf(
                NurseReview("rev_5", "عبدالله الشهري (بيانات تجريبية)", 4.7f, "ملتزم بالوقت وأسلوبه مطمئن جداً.", "منذ أسبوعين")
            )
        ),
        NurseProfile(
            id = "nurse_5",
            nameAr = "أ. ريم المطيري",
            titleAr = "ممرضة رعاية ما بعد الجراحة",
            specialtyAr = "التعافي الجراحي والأمومة",
            primaryCategory = ServiceCategory.POST_SURGERY,
            cityAr = "الرياض",
            neighborhoodAr = "حي حطين",
            experienceYears = 7,
            licenseNumber = "NL-DEMO-5518",
            rating = 4.85,
            reviewsCount = 57,
            completedVisits = 194,
            isVerified = true,
            isAvailableToday = true,
            bioAr = "متخصصة في دعم المرضى خلال الأسابيع الأولى بعد العمليات الجراحية، وتخفيف القلق من خلال زيارات منزلية منظمة.",
            languagesAr = listOf("العربية", "الإنجليزية"),
            avatarStyle = AvatarStyle.MONOGRAM_SAGE,
            avatarResId = null,
            services = listOf(
                NursingService(
                    id = "srv_501",
                    titleAr = "برنامج العناية بعد الولادة والعمليات",
                    descriptionAr = "متابعة شاملة للجرح الجراحي، قياس المؤشرات، وتوجيهات العناية اليومية.",
                    category = ServiceCategory.POST_SURGERY,
                    priceSar = 230,
                    durationMinutes = 60
                ),
                NursingService(
                    id = "srv_502",
                    titleAr = "جلسة حقن دوائي منزلي",
                    descriptionAr = "تنفيذ الحقن الموصوفة مع تعقيم كامل ومتابعة فورية.",
                    category = ServiceCategory.INJECTIONS_IV,
                    priceSar = 90,
                    durationMinutes = 20
                )
            )
        )
    )

    private val initialBookings = listOf(
        BookingRequest(
            id = "bk_1001",
            nurseId = "nurse_1",
            nurseNameAr = "أ. سارة القحطاني",
            nurseTitleAr = "أخصائية تمريض منزلي أول",
            patientNameAr = "نورة العبدالله (افتراضي)",
            patientDistrictAr = "الرياض - حي الملقا",
            serviceId = "srv_101",
            serviceTitleAr = "جلسة رعاية كبار السن الشاملة",
            servicePriceSar = 180,
            homeVisitFeeSar = 30,
            dateLabelAr = "اليوم • الإثنين",
            timeSlotAr = "04:30 م",
            notesAr = "زيارة مسائية لقياس الضغط ومتابعة جدول الأدوية اليومي.",
            status = BookingStatus.PENDING,
            createdAtLabelAr = "منذ 15 دقيقة"
        ),
        BookingRequest(
            id = "bk_1002",
            nurseId = "nurse_1",
            nurseNameAr = "أ. سارة القحطاني",
            nurseTitleAr = "أخصائية تمريض منزلي أول",
            patientNameAr = "سعد المري (افتراضي)",
            patientDistrictAr = "الرياض - حي الياسمين",
            serviceId = "srv_102",
            serviceTitleAr = "تغيير وتضميد الجروح المعقم",
            servicePriceSar = 140,
            homeVisitFeeSar = 30,
            dateLabelAr = "غداً • الثلاثاء",
            timeSlotAr = "11:30 ص",
            notesAr = "تغيير ضماد روتيني بعد عملية بسيطة.",
            status = BookingStatus.CONFIRMED,
            createdAtLabelAr = "منذ ساعتين"
        ),
        BookingRequest(
            id = "bk_1003",
            nurseId = "nurse_2",
            nurseNameAr = "أ. أحمد الغامدي",
            nurseTitleAr = "ممرض رعاية حرجة ومنزلية",
            patientNameAr = "فيصل الدخيل (افتراضي)",
            patientDistrictAr = "الرياض - حي النرجس",
            serviceId = "srv_201",
            serviceTitleAr = "إعطاء الحقن العضلية أو تحت الجلد",
            servicePriceSar = 85,
            homeVisitFeeSar = 30,
            dateLabelAr = "أمس • الأحد",
            timeSlotAr = "07:00 م",
            notesAr = "تم إتمام الزيارة بنجاح.",
            status = BookingStatus.COMPLETED,
            createdAtLabelAr = "منذ يوم واحد"
        )
    )

    private val _nurses = MutableStateFlow(initialNurses)
    val nurses: StateFlow<List<NurseProfile>> = _nurses.asStateFlow()

    private val _bookings = MutableStateFlow(initialBookings)
    val bookings: StateFlow<List<BookingRequest>> = _bookings.asStateFlow()

    private val _activeNurseId = MutableStateFlow("nurse_1")
    val activeNurseId: StateFlow<String> = _activeNurseId.asStateFlow()

    fun createBooking(
        nurse: NurseProfile,
        service: NursingService,
        patientNameAr: String,
        patientDistrictAr: String,
        dateLabelAr: String,
        timeSlotAr: String,
        notesAr: String
    ): BookingRequest {
        val newBooking = BookingRequest(
            id = "bk_${UUID.randomUUID().toString().take(6)}",
            nurseId = nurse.id,
            nurseNameAr = nurse.nameAr,
            nurseTitleAr = nurse.titleAr,
            patientNameAr = patientNameAr.ifBlank { "زائر تجريبي" },
            patientDistrictAr = patientDistrictAr.ifBlank { "${nurse.cityAr} - ${nurse.neighborhoodAr}" },
            serviceId = service.id,
            serviceTitleAr = service.titleAr,
            servicePriceSar = service.priceSar,
            homeVisitFeeSar = 30,
            dateLabelAr = dateLabelAr,
            timeSlotAr = timeSlotAr,
            notesAr = notesAr.ifBlank { "لا توجد ملاحظات إضافية." },
            status = BookingStatus.PENDING,
            createdAtLabelAr = "الآن"
        )
        _bookings.update { listOf(newBooking) + it }
        return newBooking
    }

    fun updateBookingStatus(bookingId: String, newStatus: BookingStatus) {
        _bookings.update { list ->
            list.map { booking ->
                if (booking.id == bookingId) booking.copy(status = newStatus) else booking
            }
        }
    }

    fun toggleNurseAvailability(nurseId: String) {
        _nurses.update { list ->
            list.map { nurse ->
                if (nurse.id == nurseId) nurse.copy(isAvailableToday = !nurse.isAvailableToday)
                else nurse
            }
        }
    }

    fun saveOrCreateNurseProfile(
        nurseId: String?,
        nameAr: String,
        titleAr: String,
        specialtyAr: String,
        category: ServiceCategory,
        cityAr: String,
        neighborhoodAr: String,
        experienceYears: Int,
        licenseNumber: String,
        bioAr: String,
        isAvailableToday: Boolean,
        avatarStyle: AvatarStyle
    ): NurseProfile {
        val existing = _nurses.value.find { it.id == nurseId }
        val resolvedAvatarRes = when (avatarStyle) {
            AvatarStyle.FEMALE_1 -> R.drawable.img_nurse_female_1
            AvatarStyle.FEMALE_2 -> R.drawable.img_nurse_female_2
            AvatarStyle.MALE_1 -> R.drawable.img_nurse_male_1
            else -> null
        }
        return if (existing != null) {
            val updated = existing.copy(
                nameAr = nameAr.trim(),
                titleAr = titleAr.trim(),
                specialtyAr = specialtyAr.trim(),
                primaryCategory = category,
                cityAr = cityAr.trim(),
                neighborhoodAr = neighborhoodAr.trim(),
                experienceYears = experienceYears,
                licenseNumber = licenseNumber.trim(),
                bioAr = bioAr.trim(),
                isAvailableToday = isAvailableToday,
                avatarStyle = avatarStyle,
                avatarResId = resolvedAvatarRes
            )
            _nurses.update { list -> list.map { if (it.id == existing.id) updated else it } }
            _activeNurseId.value = updated.id
            updated
        } else {
            val newId = "nurse_${UUID.randomUUID().toString().take(6)}"
            val created = NurseProfile(
                id = newId,
                nameAr = nameAr.trim(),
                titleAr = titleAr.trim(),
                specialtyAr = specialtyAr.trim(),
                primaryCategory = category,
                cityAr = cityAr.trim(),
                neighborhoodAr = neighborhoodAr.trim(),
                experienceYears = experienceYears,
                licenseNumber = licenseNumber.trim().ifBlank { "NL-DEMO-9012" },
                rating = 5.0,
                reviewsCount = 1,
                completedVisits = 0,
                isVerified = true,
                isAvailableToday = isAvailableToday,
                bioAr = bioAr.trim(),
                languagesAr = listOf("العربية"),
                avatarStyle = avatarStyle,
                avatarResId = resolvedAvatarRes,
                services = listOf(
                    NursingService(
                        id = "srv_${UUID.randomUUID().toString().take(5)}",
                        titleAr = "استشارة وزيارة تمريضية منزلية",
                        descriptionAr = "زيارة تمريضية أولية وتقييم الاحتياجات المنزلية.",
                        category = category,
                        priceSar = 160,
                        durationMinutes = 45
                    )
                )
            )
            _nurses.update { listOf(created) + it }
            _activeNurseId.value = created.id
            created
        }
    }

    fun selectActiveNurse(nurseId: String) {
        _activeNurseId.value = nurseId
    }

    fun addNurseService(
        nurseId: String,
        titleAr: String,
        descriptionAr: String,
        category: ServiceCategory,
        priceSar: Int,
        durationMinutes: Int
    ) {
        val service = NursingService(
            id = "srv_${UUID.randomUUID().toString().take(6)}",
            titleAr = titleAr.trim(),
            descriptionAr = descriptionAr.trim().ifBlank { "خدمة تمريضية منزلية وفق معايير السلامة." },
            category = category,
            priceSar = priceSar,
            durationMinutes = durationMinutes,
            isActive = true
        )
        _nurses.update { list ->
            list.map { nurse ->
                if (nurse.id == nurseId) nurse.copy(services = listOf(service) + nurse.services)
                else nurse
            }
        }
    }

    fun toggleServiceActive(nurseId: String, serviceId: String) {
        _nurses.update { list ->
            list.map { nurse ->
                if (nurse.id == nurseId) {
                    nurse.copy(
                        services = nurse.services.map { srv ->
                            if (srv.id == serviceId) srv.copy(isActive = !srv.isActive) else srv
                        }
                    )
                } else nurse
            }
        }
    }

    fun deleteNurseService(nurseId: String, serviceId: String) {
        _nurses.update { list ->
            list.map { nurse ->
                if (nurse.id == nurseId) {
                    nurse.copy(services = nurse.services.filterNot { it.id == serviceId })
                } else nurse
            }
        }
    }
}
