package com.example.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MedicalServices
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MedicalServices
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.model.BookingStatus
import com.example.model.UserRole
import com.example.ui.screens.BookingScreen
import com.example.ui.screens.NurseDashboardScreen
import com.example.ui.screens.NurseProfileEditorScreen
import com.example.ui.screens.NurseProfileScreen
import com.example.ui.screens.NurseServicesTabScreen
import com.example.ui.screens.PatientBookingsScreen
import com.example.ui.screens.PatientHomeScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.MintLight
import com.example.viewmodel.NurseLinkViewModel

object Routes {
    const val WELCOME = "welcome"
    const val PATIENT_SHELL = "patient_shell"
    const val NURSE_SHELL = "nurse_shell"
    const val NURSE_PROFILE = "nurse_profile/{nurseId}"
    const val BOOKING = "booking/{nurseId}?serviceId={serviceId}"

    fun nurseProfile(nurseId: String) = "nurse_profile/$nurseId"
    fun booking(nurseId: String, serviceId: String? = null): String {
        return if (serviceId.isNullOrBlank()) "booking/$nurseId"
        else "booking/$nurseId?serviceId=$serviceId"
    }
}

private enum class PatientTab(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME(R.string.tab_home, Icons.Rounded.Home, Icons.Outlined.Home),
    BOOKINGS(R.string.tab_bookings, Icons.Rounded.CalendarMonth, Icons.Outlined.CalendarMonth)
}

private enum class NurseTab(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD(R.string.tab_dashboard, Icons.Rounded.Dashboard, Icons.Outlined.Dashboard),
    SERVICES(R.string.tab_services, Icons.Rounded.MedicalServices, Icons.Outlined.MedicalServices),
    PROFILE(R.string.tab_profile, Icons.Rounded.Person, Icons.Outlined.Person)
}

@Composable
fun NurseLinkNavGraph(
    viewModel: NurseLinkViewModel = viewModel()
) {
    val navController = rememberNavController()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var activePatientTab by rememberSaveable { mutableStateOf(PatientTab.HOME) }
    var activeNurseTab by rememberSaveable { mutableStateOf(NurseTab.DASHBOARD) }

    NavHost(
        navController = navController,
        startDestination = Routes.WELCOME
    ) {
        composable(Routes.WELCOME) {
            WelcomeScreen(
                onSelectRole = { role ->
                    viewModel.selectRole(role)
                    when (role) {
                        UserRole.PATIENT -> {
                            activePatientTab = PatientTab.HOME
                            navController.navigate(Routes.PATIENT_SHELL)
                        }
                        UserRole.NURSE -> {
                            activeNurseTab = NurseTab.DASHBOARD
                            navController.navigate(Routes.NURSE_SHELL)
                        }
                    }
                }
            )
        }

        composable(Routes.PATIENT_SHELL) {
            if (activePatientTab != PatientTab.HOME) {
                BackHandler { activePatientTab = PatientTab.HOME }
            }

            val pendingCount = uiState.allBookings.count {
                it.status == BookingStatus.PENDING || it.status == BookingStatus.CONFIRMED
            }

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useRail = maxWidth >= 680.dp

                val content: @Composable (Modifier) -> Unit = { contentModifier ->
                    when (activePatientTab) {
                        PatientTab.HOME -> {
                            PatientHomeScreen(
                                uiState = uiState,
                                onSearchQueryChange = viewModel::updateSearchQuery,
                                onSelectCategory = viewModel::selectCategory,
                                onToggleAvailableToday = viewModel::toggleOnlyAvailableToday,
                                onOpenNurseProfile = { nurseId ->
                                    navController.navigate(Routes.nurseProfile(nurseId))
                                },
                                onBookNurse = { nurseId ->
                                    navController.navigate(Routes.booking(nurseId))
                                },
                                onSwitchRole = {
                                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                                },
                                modifier = contentModifier
                            )
                        }

                        PatientTab.BOOKINGS -> {
                            PatientBookingsScreen(
                                bookings = uiState.allBookings,
                                onOpenNurseProfile = { nurseId ->
                                    navController.navigate(Routes.nurseProfile(nurseId))
                                },
                                onCancelBooking = viewModel::cancelBookingAsPatient,
                                onExploreNurses = { activePatientTab = PatientTab.HOME },
                                onSwitchRole = {
                                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                                },
                                modifier = contentModifier
                            )
                        }
                    }
                }

                if (useRail) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        NavigationRail(
                            modifier = Modifier
                                .fillMaxHeight()
                                .statusBarsPadding(),
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            PatientTab.entries.forEach { tab ->
                                val selected = activePatientTab == tab
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { activePatientTab = tab },
                                    modifier = Modifier.testTag("patient_nav_${tab.name.lowercase()}"),
                                    icon = {
                                        BadgedBox(
                                            badge = {
                                                if (tab == PatientTab.BOOKINGS && pendingCount > 0) {
                                                    Badge { Text("$pendingCount") }
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = stringResource(tab.labelRes)
                                            )
                                        }
                                    },
                                    label = { Text(stringResource(tab.labelRes)) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = EmeraldDark,
                                        selectedTextColor = EmeraldDark,
                                        indicatorColor = MintLight
                                    )
                                )
                            }
                        }
                        content(Modifier.weight(1f))
                    }
                } else {
                    Scaffold(
                        contentWindowInsets = WindowInsets(0, 0, 0, 0),
                        bottomBar = {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 4.dp
                            ) {
                                PatientTab.entries.forEach { tab ->
                                    val selected = activePatientTab == tab
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { activePatientTab = tab },
                                        modifier = Modifier.testTag("patient_nav_${tab.name.lowercase()}"),
                                        icon = {
                                            BadgedBox(
                                                badge = {
                                                    if (tab == PatientTab.BOOKINGS && pendingCount > 0) {
                                                        Badge { Text("$pendingCount") }
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = stringResource(tab.labelRes)
                                                )
                                            }
                                        },
                                        label = { Text(stringResource(tab.labelRes)) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = EmeraldDark,
                                            selectedTextColor = EmeraldDark,
                                            indicatorColor = MintLight
                                        )
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        content(Modifier.padding(innerPadding))
                    }
                }
            }
        }

        composable(Routes.NURSE_SHELL) {
            if (activeNurseTab != NurseTab.DASHBOARD) {
                BackHandler { activeNurseTab = NurseTab.DASHBOARD }
            }

            val pendingRequestsCount = uiState.activeNurseBookings.count {
                it.status == BookingStatus.PENDING
            }

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useRail = maxWidth >= 680.dp

                val content: @Composable (Modifier) -> Unit = { contentModifier ->
                    when (activeNurseTab) {
                        NurseTab.DASHBOARD -> {
                            NurseDashboardScreen(
                                activeNurse = uiState.activeNurse,
                                allNurses = uiState.nurses,
                                bookings = uiState.activeNurseBookings,
                                onSelectActiveNurse = viewModel::selectActiveNurse,
                                onToggleAvailability = viewModel::toggleActiveNurseAvailability,
                                onAcceptBooking = viewModel::acceptBookingAsNurse,
                                onDeclineBooking = viewModel::declineBookingAsNurse,
                                onCompleteBooking = viewModel::completeBookingAsNurse,
                                onSwitchRole = {
                                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                                },
                                modifier = contentModifier
                            )
                        }

                        NurseTab.SERVICES -> {
                            NurseServicesTabScreen(
                                activeNurse = uiState.activeNurse,
                                onAddService = viewModel::addServiceForActiveNurse,
                                onToggleServiceActive = viewModel::toggleServiceActive,
                                onDeleteService = viewModel::deleteService,
                                onSwitchRole = {
                                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                                },
                                modifier = contentModifier
                            )
                        }

                        NurseTab.PROFILE -> {
                            NurseProfileEditorScreen(
                                activeNurse = uiState.activeNurse,
                                onSaveProfile = { createNew, name, title, specialty, cat, city, neighborhood, exp, license, bio, avail, avatar ->
                                    viewModel.saveOrCreateNurseProfile(
                                        createNew = createNew,
                                        nameAr = name,
                                        titleAr = title,
                                        specialtyAr = specialty,
                                        category = cat,
                                        cityAr = city,
                                        neighborhoodAr = neighborhood,
                                        experienceYears = exp,
                                        licenseNumber = license,
                                        bioAr = bio,
                                        isAvailableToday = avail,
                                        avatarStyle = avatar
                                    )
                                },
                                onSwitchRole = {
                                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                                },
                                modifier = contentModifier
                            )
                        }
                    }
                }

                if (useRail) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        NavigationRail(
                            modifier = Modifier
                                .fillMaxHeight()
                                .statusBarsPadding(),
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            NurseTab.entries.forEach { tab ->
                                val selected = activeNurseTab == tab
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { activeNurseTab = tab },
                                    modifier = Modifier.testTag("nurse_nav_${tab.name.lowercase()}"),
                                    icon = {
                                        BadgedBox(
                                            badge = {
                                                if (tab == NurseTab.DASHBOARD && pendingRequestsCount > 0) {
                                                    Badge { Text("$pendingRequestsCount") }
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = stringResource(tab.labelRes)
                                            )
                                        }
                                    },
                                    label = { Text(stringResource(tab.labelRes)) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = EmeraldDark,
                                        selectedTextColor = EmeraldDark,
                                        indicatorColor = MintLight
                                    )
                                )
                            }
                        }
                        content(Modifier.weight(1f))
                    }
                } else {
                    Scaffold(
                        contentWindowInsets = WindowInsets(0, 0, 0, 0),
                        bottomBar = {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 4.dp
                            ) {
                                NurseTab.entries.forEach { tab ->
                                    val selected = activeNurseTab == tab
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { activeNurseTab = tab },
                                        modifier = Modifier.testTag("nurse_nav_${tab.name.lowercase()}"),
                                        icon = {
                                            BadgedBox(
                                                badge = {
                                                    if (tab == NurseTab.DASHBOARD && pendingRequestsCount > 0) {
                                                        Badge { Text("$pendingRequestsCount") }
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = stringResource(tab.labelRes)
                                                )
                                            }
                                        },
                                        label = { Text(stringResource(tab.labelRes)) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = EmeraldDark,
                                            selectedTextColor = EmeraldDark,
                                            indicatorColor = MintLight
                                        )
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        content(Modifier.padding(innerPadding))
                    }
                }
            }
        }

        composable(
            route = Routes.NURSE_PROFILE,
            arguments = listOf(navArgument("nurseId") { type = NavType.StringType })
        ) { backStackEntry ->
            val nurseId = backStackEntry.arguments?.getString("nurseId").orEmpty()
            val nurse = viewModel.getNurseById(nurseId) ?: uiState.nurses.firstOrNull()
            if (nurse != null) {
                NurseProfileScreen(
                    nurse = nurse,
                    onBack = { navController.popBackStack() },
                    onBookService = { id, serviceId ->
                        navController.navigate(Routes.booking(id, serviceId))
                    }
                )
            }
        }

        composable(
            route = Routes.BOOKING,
            arguments = listOf(
                navArgument("nurseId") { type = NavType.StringType },
                navArgument("serviceId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val nurseId = backStackEntry.arguments?.getString("nurseId").orEmpty()
            val serviceId = backStackEntry.arguments?.getString("serviceId")
            val nurse = viewModel.getNurseById(nurseId) ?: uiState.nurses.firstOrNull()
            if (nurse != null) {
                BookingScreen(
                    nurse = nurse,
                    initialServiceId = serviceId,
                    onBack = { navController.popBackStack() },
                    onSubmitBooking = { service, patientName, district, dateLabel, timeSlot, notes ->
                        viewModel.submitBooking(
                            nurse = nurse,
                            service = service,
                            patientNameAr = patientName,
                            patientDistrictAr = district,
                            dateLabelAr = dateLabel,
                            timeSlotAr = timeSlot,
                            notesAr = notes
                        )
                    },
                    onGoToMyBookings = {
                        activePatientTab = PatientTab.BOOKINGS
                        navController.popBackStack(Routes.PATIENT_SHELL, inclusive = false)
                    },
                    onReturnHome = {
                        activePatientTab = PatientTab.HOME
                        navController.popBackStack(Routes.PATIENT_SHELL, inclusive = false)
                    }
                )
            }
        }
    }
}
