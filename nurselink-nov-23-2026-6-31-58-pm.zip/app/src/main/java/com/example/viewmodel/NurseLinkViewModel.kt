package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.NurseLinkRepository
import com.example.model.AvatarStyle
import com.example.model.BookingRequest
import com.example.model.BookingStatus
import com.example.model.NurseProfile
import com.example.model.NursingService
import com.example.model.ServiceCategory
import com.example.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

data class NurseLinkUiState(
    val selectedRole: UserRole? = null,
    val searchQuery: String = "",
    val selectedCategory: ServiceCategory = ServiceCategory.ALL,
    val onlyAvailableToday: Boolean = false,
    val nurses: List<NurseProfile> = emptyList(),
    val filteredNurses: List<NurseProfile> = emptyList(),
    val allBookings: List<BookingRequest> = emptyList(),
    val activeNurse: NurseProfile? = null,
    val activeNurseBookings: List<BookingRequest> = emptyList()
)

class NurseLinkViewModel : ViewModel() {

    private val _selectedRole = MutableStateFlow<UserRole?>(null)
    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow(ServiceCategory.ALL)
    private val _onlyAvailableToday = MutableStateFlow(false)

    private val filterFlow = combine(
        _selectedRole,
        _searchQuery,
        _selectedCategory,
        _onlyAvailableToday
    ) { role, query, category, onlyAvailable ->
        FilterParams(role, query, category, onlyAvailable)
    }

    val uiState: StateFlow<NurseLinkUiState> = combine(
        filterFlow,
        NurseLinkRepository.nurses,
        NurseLinkRepository.bookings,
        NurseLinkRepository.activeNurseId
    ) { filters, nurses, bookings, activeNurseId ->
        val trimmed = filters.query.trim()
        val filtered = nurses.filter { nurse ->
            val matchesCategory = filters.category == ServiceCategory.ALL ||
                nurse.primaryCategory == filters.category ||
                nurse.services.any { it.isActive && it.category == filters.category }

            val matchesAvailability = !filters.onlyAvailableToday || nurse.isAvailableToday

            val matchesQuery = trimmed.isEmpty() ||
                nurse.nameAr.contains(trimmed, ignoreCase = true) ||
                nurse.specialtyAr.contains(trimmed, ignoreCase = true) ||
                nurse.cityAr.contains(trimmed, ignoreCase = true) ||
                nurse.neighborhoodAr.contains(trimmed, ignoreCase = true) ||
                nurse.services.any { it.titleAr.contains(trimmed, ignoreCase = true) }

            matchesCategory && matchesAvailability && matchesQuery
        }

        val activeNurse = nurses.find { it.id == activeNurseId } ?: nurses.firstOrNull()
        val nurseBookings = if (activeNurse != null) {
            bookings.filter { it.nurseId == activeNurse.id }
        } else emptyList()

        NurseLinkUiState(
            selectedRole = filters.role,
            searchQuery = filters.query,
            selectedCategory = filters.category,
            onlyAvailableToday = filters.onlyAvailableToday,
            nurses = nurses,
            filteredNurses = filtered,
            allBookings = bookings,
            activeNurse = activeNurse,
            activeNurseBookings = nurseBookings
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = NurseLinkUiState(
            nurses = NurseLinkRepository.nurses.value,
            filteredNurses = NurseLinkRepository.nurses.value,
            allBookings = NurseLinkRepository.bookings.value,
            activeNurse = NurseLinkRepository.nurses.value.firstOrNull()
        )
    )

    fun selectRole(role: UserRole) {
        _selectedRole.value = role
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: ServiceCategory) {
        _selectedCategory.update { category }
    }

    fun toggleOnlyAvailableToday() {
        _onlyAvailableToday.update { !it }
    }

    fun getNurseById(nurseId: String): NurseProfile? {
        return uiState.value.nurses.find { it.id == nurseId }
    }

    fun submitBooking(
        nurse: NurseProfile,
        service: NursingService,
        patientNameAr: String,
        patientDistrictAr: String,
        dateLabelAr: String,
        timeSlotAr: String,
        notesAr: String
    ): BookingRequest {
        return NurseLinkRepository.createBooking(
            nurse = nurse,
            service = service,
            patientNameAr = patientNameAr,
            patientDistrictAr = patientDistrictAr,
            dateLabelAr = dateLabelAr,
            timeSlotAr = timeSlotAr,
            notesAr = notesAr
        )
    }

    fun cancelBookingAsPatient(bookingId: String) {
        NurseLinkRepository.updateBookingStatus(bookingId, BookingStatus.CANCELLED)
    }

    fun acceptBookingAsNurse(bookingId: String) {
        NurseLinkRepository.updateBookingStatus(bookingId, BookingStatus.CONFIRMED)
    }

    fun declineBookingAsNurse(bookingId: String) {
        NurseLinkRepository.updateBookingStatus(bookingId, BookingStatus.DECLINED)
    }

    fun completeBookingAsNurse(bookingId: String) {
        NurseLinkRepository.updateBookingStatus(bookingId, BookingStatus.COMPLETED)
    }

    fun toggleActiveNurseAvailability() {
        val current = uiState.value.activeNurse ?: return
        NurseLinkRepository.toggleNurseAvailability(current.id)
    }

    fun selectActiveNurse(nurseId: String) {
        NurseLinkRepository.selectActiveNurse(nurseId)
    }

    fun saveOrCreateNurseProfile(
        createNew: Boolean,
        nameAr: String,
        titleAr: String,
        specialtyAr: String,
        category: ServiceCategory,
        cityAr: String,
        neighborhoodAr: String,
        experienceYears: Int,
        licenseNumber: String,
        bioAr: String,
        isAvailableToday: Boolean,
        avatarStyle: AvatarStyle
    ): NurseProfile {
        val targetId = if (createNew) null else uiState.value.activeNurse?.id
        return NurseLinkRepository.saveOrCreateNurseProfile(
            nurseId = targetId,
            nameAr = nameAr,
            titleAr = titleAr,
            specialtyAr = specialtyAr,
            category = category,
            cityAr = cityAr,
            neighborhoodAr = neighborhoodAr,
            experienceYears = experienceYears,
            licenseNumber = licenseNumber,
            bioAr = bioAr,
            isAvailableToday = isAvailableToday,
            avatarStyle = avatarStyle
        )
    }

    fun addServiceForActiveNurse(
        titleAr: String,
        descriptionAr: String,
        category: ServiceCategory,
        priceSar: Int,
        durationMinutes: Int
    ) {
        val current = uiState.value.activeNurse ?: return
        NurseLinkRepository.addNurseService(
            nurseId = current.id,
            titleAr = titleAr,
            descriptionAr = descriptionAr,
            category = category,
            priceSar = priceSar,
            durationMinutes = durationMinutes
        )
    }

    fun toggleServiceActive(serviceId: String) {
        val current = uiState.value.activeNurse ?: return
        NurseLinkRepository.toggleServiceActive(current.id, serviceId)
    }

    fun deleteService(serviceId: String) {
        val current = uiState.value.activeNurse ?: return
        NurseLinkRepository.deleteNurseService(current.id, serviceId)
    }

    private data class FilterParams(
        val role: UserRole?,
        val query: String,
        val category: ServiceCategory,
        val onlyAvailableToday: Boolean
    )
}
