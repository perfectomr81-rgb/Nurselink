package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.LocationCity
import androidx.compose.material.icons.rounded.MedicalServices
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AvatarStyle
import com.example.model.NurseProfile
import com.example.model.NursingService
import com.example.model.ServiceCategory
import com.example.ui.components.DurationLabel
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.NurseAvatar
import com.example.ui.components.PricePill
import com.example.ui.components.RoleSwitchChip
import com.example.ui.components.icon
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVibrant
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintSoft
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusDeclinedFg

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NurseServicesTabScreen(
    activeNurse: NurseProfile?,
    onAddService: (title: String, desc: String, category: ServiceCategory, priceSar: Int, durationMin: Int) -> Unit,
    onToggleServiceActive: (String) -> Unit,
    onDeleteService: (String) -> Unit,
    onSwitchRole: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddSheet by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddSheet = true },
                modifier = Modifier.testTag("add_service_fab"),
                containerColor = EmeraldDark,
                contentColor = PureWhite
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "إضافة خدمة")
                    Text("إضافة خدمة", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    ) { innerPadding ->
        val services = activeNurse?.services.orEmpty()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 88.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(EmeraldDeep, EmeraldDark)))
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "خدماتي وأسعاري",
                                style = MaterialTheme.typography.headlineSmall,
                                color = PureWhite
                            )
                            Text(
                                text = "${activeNurse?.nameAr.orEmpty()} • ${services.size} خدمة مدرجة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MintLight
                            )
                        }
                        RoleSwitchChip(
                            currentRoleLabel = stringResource(R.string.switch_role),
                            onSwitchRole = onSwitchRole
                        )
                    }
                }
            }

            if (services.isEmpty()) {
                item {
                    Box(modifier = Modifier.padding(20.dp)) {
                        EmptyStateCard(
                            icon = Icons.Rounded.MedicalServices,
                            title = "لم تقم بإضافة خدمات بعد",
                            subtitle = "أضف خدماتك التمريضية وحدد الأسعار والمدة ليتمكن المرضى من حجزها."
                        )
                    }
                }
            } else {
                items(services, key = { it.id }) { service ->
                    NurseManagedServiceCard(
                        service = service,
                        onToggle = { onToggleServiceActive(service.id) },
                        onDelete = { onDeleteService(service.id) },
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }

    if (showAddSheet) {
        var title by rememberSaveable { mutableStateOf("") }
        var desc by rememberSaveable { mutableStateOf("") }
        var priceText by rememberSaveable { mutableStateOf("150") }
        var durationText by rememberSaveable { mutableStateOf("45") }
        var category by rememberSaveable { mutableStateOf(ServiceCategory.HOME_CHECKUP) }
        var errorMsg by rememberSaveable { mutableStateOf<String?>(null) }

        ModalBottomSheet(
            onDismissRequest = { showAddSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "إضافة خدمة تمريضية جديدة",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        errorMsg = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_service_title_input"),
                    label = { Text("اسم الخدمة") },
                    placeholder = { Text("مثال: متابعة ضغط الدم والسكري") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("وصف مختصر للخدمة") },
                    placeholder = { Text("اشرح ما تشمله الزيارة للمريض") },
                    minLines = 2,
                    maxLines = 3,
                    shape = RoundedCornerShape(14.dp)
                )

                Text(
                    text = "تصنيف الخدمة",
                    style = MaterialTheme.typography.labelLarge
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ServiceCategory.entries
                        .filter { it != ServiceCategory.ALL }
                        .forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat.labelAr) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldDark,
                                    selectedLabelColor = PureWhite
                                )
                            )
                        }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it.filter { ch -> ch.isDigit() } },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("new_service_price_input"),
                        label = { Text("السعر (ر.س)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { durationText = it.filter { ch -> ch.isDigit() } },
                        modifier = Modifier.weight(1f),
                        label = { Text("المدة (دقيقة)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusDeclinedFg
                    )
                }

                Button(
                    onClick = {
                        val parsedPrice = priceText.toIntOrNull() ?: 0
                        val parsedDuration = durationText.toIntOrNull() ?: 30
                        if (title.isBlank() || parsedPrice <= 0) {
                            errorMsg = "يرجى إدخال اسم الخدمة وسعر صحيح أكبر من صفر."
                        } else {
                            onAddService(
                                title,
                                desc,
                                category,
                                parsedPrice,
                                parsedDuration.coerceIn(10, 480)
                            )
                            showAddSheet = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("save_new_service_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)
                ) {
                    Text("حفظ ونشر الخدمة")
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun NurseManagedServiceCard(
    service: NursingService,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MintSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = service.category.icon(),
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = service.titleAr,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = service.category.labelAr,
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldVibrant
                        )
                    }
                }
                PricePill(priceSar = service.priceSar)
            }

            Text(
                text = service.descriptionAr,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DurationLabel(durationMinutes = service.durationMinutes)

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (service.isActive) "مفعّلة" else "متوقفة",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Switch(
                        checked = service.isActive,
                        onCheckedChange = { onToggle() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PureWhite,
                            checkedTrackColor = EmeraldDark
                        )
                    )
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "حذف الخدمة",
                            tint = StatusDeclinedFg
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NurseProfileEditorScreen(
    activeNurse: NurseProfile?,
    onSaveProfile: (
        createNew: Boolean,
        nameAr: String,
        titleAr: String,
        specialtyAr: String,
        category: ServiceCategory,
        cityAr: String,
        neighborhoodAr: String,
        experienceYears: Int,
        licenseNumber: String,
        bioAr: String,
        isAvailableToday: Boolean,
        avatarStyle: AvatarStyle
    ) -> Unit,
    onSwitchRole: () -> Unit,
    modifier: Modifier = Modifier
) {
    var createNewMode by rememberSaveable { mutableStateOf(false) }
    var nameAr by rememberSaveable { mutableStateOf(activeNurse?.nameAr ?: "") }
    var titleAr by rememberSaveable { mutableStateOf(activeNurse?.titleAr ?: "") }
    var specialtyAr by rememberSaveable { mutableStateOf(activeNurse?.specialtyAr ?: "") }
    var category by rememberSaveable { mutableStateOf(activeNurse?.primaryCategory ?: ServiceCategory.ELDERLY_CARE) }
    var cityAr by rememberSaveable { mutableStateOf(activeNurse?.cityAr ?: "الرياض") }
    var neighborhoodAr by rememberSaveable { mutableStateOf(activeNurse?.neighborhoodAr ?: "حي الملقا") }
    var experienceText by rememberSaveable { mutableStateOf((activeNurse?.experienceYears ?: 4).toString()) }
    var licenseNumber by rememberSaveable { mutableStateOf(activeNurse?.licenseNumber ?: "NL-DEMO-8820") }
    var bioAr by rememberSaveable { mutableStateOf(activeNurse?.bioAr ?: "") }
    var isAvailableToday by rememberSaveable { mutableStateOf(activeNurse?.isAvailableToday ?: true) }
    var avatarStyle by rememberSaveable { mutableStateOf(activeNurse?.avatarStyle ?: AvatarStyle.FEMALE_1) }
    var savedNotice by rememberSaveable { mutableStateOf<String?>(null) }

    LaunchedEffect(activeNurse?.id, createNewMode) {
        if (!createNewMode && activeNurse != null) {
            nameAr = activeNurse.nameAr
            titleAr = activeNurse.titleAr
            specialtyAr = activeNurse.specialtyAr
            category = activeNurse.primaryCategory
            cityAr = activeNurse.cityAr
            neighborhoodAr = activeNurse.neighborhoodAr
            experienceText = activeNurse.experienceYears.toString()
            licenseNumber = activeNurse.licenseNumber
            bioAr = activeNurse.bioAr
            isAvailableToday = activeNurse.isAvailableToday
            avatarStyle = activeNurse.avatarStyle
        } else if (createNewMode) {
            nameAr = ""
            titleAr = "أخصائي تمريض منزلي"
            specialtyAr = "الرعاية التمريضية المنزلية"
            category = ServiceCategory.HOME_CHECKUP
            cityAr = "الرياض"
            neighborhoodAr = "حي النخيل"
            experienceText = "5"
            licenseNumber = "NL-DEMO-9401"
            bioAr = "ممرض مرخص لتقديم الرعاية المنزلية الموثوقة وفق معايير السلامة."
            isAvailableToday = true
            avatarStyle = AvatarStyle.MALE_1
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(EmeraldDeep, EmeraldDark)))
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "إعداد الملف المهني",
                            style = MaterialTheme.typography.headlineSmall,
                            color = PureWhite
                        )
                        Text(
                            text = "أنشئ ملفاً جديداً أو حدّث بياناتك الظاهرة للمرضى",
                            style = MaterialTheme.typography.bodySmall,
                            color = MintLight
                        )
                    }
                    RoleSwitchChip(
                        currentRoleLabel = stringResource(R.string.switch_role),
                        onSwitchRole = onSwitchRole
                    )
                }
            }
        }

        item {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Mode Toggle: Edit Existing vs Create New Profile
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ModeTogglePill(
                        label = "تحديث ملفي الحالي",
                        selected = !createNewMode,
                        onClick = {
                            createNewMode = false
                            savedNotice = null
                        },
                        modifier = Modifier.weight(1f)
                    )
                    ModeTogglePill(
                        label = "إنشاء ملف ممرض جديد",
                        selected = createNewMode,
                        onClick = {
                            createNewMode = true
                            savedNotice = null
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("create_new_nurse_profile_tab")
                    )
                }

                if (savedNotice != null) {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MintLight,
                        border = BorderStroke(1.dp, EmeraldVibrant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldDark
                            )
                            Text(
                                text = savedNotice!!,
                                style = MaterialTheme.typography.bodyMedium,
                                color = EmeraldDeep,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                if (!createNewMode && activeNurse != null) {
                    Surface(
                        shape = MaterialTheme.shapes.large,
                        color = MintSoft,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            NurseAvatar(nurse = activeNurse, size = 58.dp)
                            Column {
                                Text(
                                    text = activeNurse.nameAr,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "يظهر هذا الملف للمرضى في نتائج البحث",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Text(
                    text = "اختر شكل الصورة الشخصية",
                    style = MaterialTheme.typography.labelLarge
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val avatarOptions = listOf(
                        AvatarStyle.FEMALE_1 to "ممرضة ١",
                        AvatarStyle.FEMALE_2 to "ممرضة ٢",
                        AvatarStyle.MALE_1 to "ممرض ١",
                        AvatarStyle.MONOGRAM_EMERALD to "شارة زمردية",
                        AvatarStyle.MONOGRAM_SAGE to "شارة خضراء"
                    )
                    avatarOptions.forEach { (style, label) ->
                        FilterChip(
                            selected = avatarStyle == style,
                            onClick = { avatarStyle = style },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldDark,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = nameAr,
                    onValueChange = { nameAr = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("nurse_profile_name_input"),
                    label = { Text("الاسم الكامل") },
                    placeholder = { Text("مثال: أ. خالد العتيبي") },
                    leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, tint = EmeraldDark) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )

                OutlinedTextField(
                    value = titleAr,
                    onValueChange = { titleAr = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("المسمى الوظيفي") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )

                OutlinedTextField(
                    value = specialtyAr,
                    onValueChange = { specialtyAr = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("التخصص الدقيق") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )

                Text(
                    text = "التصنيف الرئيسي",
                    style = MaterialTheme.typography.labelLarge
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ServiceCategory.entries
                        .filter { it != ServiceCategory.ALL }
                        .forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat.labelAr) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldDark,
                                    selectedLabelColor = PureWhite
                                )
                            )
                        }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = cityAr,
                        onValueChange = { cityAr = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("المدينة") },
                        leadingIcon = { Icon(Icons.Rounded.LocationCity, contentDescription = null, tint = EmeraldDark) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = neighborhoodAr,
                        onValueChange = { neighborhoodAr = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("الحي") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = experienceText,
                        onValueChange = { experienceText = it.filter { ch -> ch.isDigit() } },
                        modifier = Modifier.weight(1f),
                        label = { Text("سنوات الخبرة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = licenseNumber,
                        onValueChange = { licenseNumber = it },
                        modifier = Modifier.weight(1.4f),
                        label = { Text("رقم الترخيص (تجريبي)") },
                        leadingIcon = { Icon(Icons.Rounded.Badge, contentDescription = null, tint = EmeraldDark) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                OutlinedTextField(
                    value = bioAr,
                    onValueChange = { bioAr = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("النبذة المهنية") },
                    minLines = 3,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp)
                )

                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MintSoft,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "متاح لاستقبال طلبات الزيارات المنزلية",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Switch(
                            checked = isAvailableToday,
                            onCheckedChange = { isAvailableToday = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = PureWhite,
                                checkedTrackColor = EmeraldDark
                            )
                        )
                    }
                }

                Button(
                    onClick = {
                        if (nameAr.isNotBlank()) {
                            onSaveProfile(
                                createNewMode,
                                nameAr,
                                titleAr.ifBlank { "أخصائي تمريض منزلي" },
                                specialtyAr.ifBlank { category.labelAr },
                                category,
                                cityAr.ifBlank { "الرياض" },
                                neighborhoodAr.ifBlank { "حي الياسمين" },
                                experienceText.toIntOrNull() ?: 3,
                                licenseNumber,
                                bioAr.ifBlank { "ممرض منزلي معتمد لتقديم الرعاية بأعلى جودة." },
                                isAvailableToday,
                                avatarStyle
                            )
                            savedNotice = if (createNewMode) {
                                "تم إنشاء الملف المهني الجديد وإضافته إلى قائمة الممرضين!"
                            } else {
                                "تم حفظ تحديثات الملف المهني بنجاح!"
                            }
                            createNewMode = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("save_nurse_profile_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldDark,
                        contentColor = PureWhite
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Save,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (createNewMode) "إنشاء ونشر الملف المهني" else "حفظ التعديلات",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun ModeTogglePill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) EmeraldDark else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (selected) EmeraldDark else MaterialTheme.colorScheme.outline)
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) PureWhite else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
