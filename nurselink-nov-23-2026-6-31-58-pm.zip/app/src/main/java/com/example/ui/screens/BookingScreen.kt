package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.BookingRequest
import com.example.model.NurseProfile
import com.example.model.NursingService
import com.example.ui.components.DurationLabel
import com.example.ui.components.NurseAvatar
import com.example.ui.components.PricePill
import com.example.ui.components.TopScreenBar
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldVibrant
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintSoft
import com.example.ui.theme.PureWhite

private val availableDateOptions = listOf(
    "اليوم • الإثنين",
    "غداً • الثلاثاء",
    "بعد غد • الأربعاء",
    "الخميس • 26 نوفمبر",
    "الجمعة • 27 نوفمبر",
    "السبت • 28 نوفمبر"
)

private val availableTimeSlots = listOf(
    "09:00 ص",
    "11:30 ص",
    "02:00 م",
    "04:30 م",
    "07:00 م",
    "09:00 م"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookingScreen(
    nurse: NurseProfile,
    initialServiceId: String?,
    onBack: () -> Unit,
    onSubmitBooking: (
        service: NursingService,
        patientName: String,
        district: String,
        dateLabel: String,
        timeSlot: String,
        notes: String
    ) -> BookingRequest,
    onGoToMyBookings: () -> Unit,
    onReturnHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeServices = nurse.services.filter { it.isActive }.ifEmpty { nurse.services }
    var selectedServiceId by rememberSaveable {
        mutableStateOf(
            activeServices.find { it.id == initialServiceId }?.id
                ?: activeServices.firstOrNull()?.id.orEmpty()
        )
    }
    var selectedDate by rememberSaveable { mutableStateOf(availableDateOptions.first()) }
    var selectedTime by rememberSaveable { mutableStateOf(availableTimeSlots[3]) }
    var patientName by rememberSaveable { mutableStateOf("عبدالرحمن السالم (افتراضي)") }
    var district by rememberSaveable { mutableStateOf("${nurse.cityAr} - ${nurse.neighborhoodAr}") }
    var notes by rememberSaveable { mutableStateOf("") }
    var createdBooking by rememberSaveable { mutableStateOf<String?>(null) }

    val selectedService = activeServices.find { it.id == selectedServiceId } ?: activeServices.first()
    val homeVisitFee = 30
    val totalCost = selectedService.priceSar + homeVisitFee

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Box(modifier = Modifier.statusBarsPadding()) {
                    TopScreenBar(
                        title = "طلب حجز زيارة تمريضية",
                        onBack = onBack
                    )
                }
            }
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 10.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "الإجمالي التقديري",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$totalCost ر.س",
                            style = MaterialTheme.typography.headlineSmall,
                            color = EmeraldDark,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            val result = onSubmitBooking(
                                selectedService,
                                patientName,
                                district,
                                selectedDate,
                                selectedTime,
                                notes
                            )
                            createdBooking = "${result.id}|${result.serviceTitleAr}|${result.dateLabelAr} - ${result.timeSlotAr}"
                        },
                        modifier = Modifier
                            .height(52.dp)
                            .testTag("confirm_booking_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldDark,
                            contentColor = PureWhite
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تأكيد طلب الحجز")
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Selected Nurse Summary
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = MintSoft,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        NurseAvatar(nurse = nurse, size = 56.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = nurse.nameAr,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${nurse.titleAr} • ${nurse.cityAr}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Step 1: Service Picker
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "١. اختر الخدمة التمريضية",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    activeServices.forEach { service ->
                        val isSelected = service.id == selectedService.id
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.medium)
                                .clickable { selectedServiceId = service.id }
                                .testTag("booking_service_option_${service.id}"),
                            shape = MaterialTheme.shapes.medium,
                            color = if (isSelected) MintLight.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) EmeraldDark else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = if (isSelected) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (isSelected) EmeraldDark else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = service.titleAr,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    DurationLabel(durationMinutes = service.durationMinutes)
                                }
                                PricePill(priceSar = service.priceSar)
                            }
                        }
                    }
                }
            }

            // Step 2: Date Picker
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CalendarToday,
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "٢. اختر يوم الزيارة",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(availableDateOptions) { dateOption ->
                            val selected = selectedDate == dateOption
                            Surface(
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { selectedDate = dateOption },
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) EmeraldDark else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) EmeraldDark else MaterialTheme.colorScheme.outline
                                )
                            ) {
                                Text(
                                    text = dateOption,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) PureWhite else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Step 3: Time Slot Picker
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Schedule,
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "٣. اختر الوقت المناسب",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        availableTimeSlots.forEach { slot ->
                            val selected = selectedTime == slot
                            Surface(
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedTime = slot },
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) EmeraldVibrant else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) EmeraldVibrant else MaterialTheme.colorScheme.outline
                                )
                            ) {
                                Text(
                                    text = slot,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) PureWhite else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Step 4: Patient Visit Info (Fictional / Non-sensitive)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "٤. بيانات الزيارة التجريبية",
                        style = MaterialTheme.typography.titleMedium
                    )

                    OutlinedTextField(
                        value = patientName,
                        onValueChange = { patientName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_patient_name_input"),
                        label = { Text("اسم المستفيد (تجريبي)") },
                        leadingIcon = {
                            Icon(Icons.Rounded.Person, contentDescription = null, tint = EmeraldDark)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )

                    OutlinedTextField(
                        value = district,
                        onValueChange = { district = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_district_input"),
                        label = { Text("المدينة والحي") },
                        leadingIcon = {
                            Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = EmeraldDark)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_notes_input"),
                        label = { Text("ملاحظات عامة للزيارة (اختياري)") },
                        placeholder = { Text("مثال: يفضل التواصل قبل الوصول بـ 15 دقيقة") },
                        minLines = 2,
                        maxLines = 3,
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }

            // Cost Breakdown & Demo Disclaimer
            item {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "ملخص التكلفة",
                            style = MaterialTheme.typography.titleMedium
                        )
                        CostLineItem("سعر الخدمة (${selectedService.titleAr})", "${selectedService.priceSar} ر.س")
                        CostLineItem("رسوم الانتقال والزيارة المنزلية", "$homeVisitFee ر.س")
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "الإجمالي التقديري",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$totalCost ر.س",
                                style = MaterialTheme.typography.titleMedium,
                                color = EmeraldDark,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MintSoft
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Info,
                                    contentDescription = null,
                                    tint = EmeraldDark,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "نموذج تجريبي: لا يتم تحصيل مدفوعات حقيقية أو حفظ سجلات طبية حساسة.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog
    val confirmationData = createdBooking
    if (confirmationData != null) {
        val parts = confirmationData.split("|")
        AlertDialog(
            onDismissRequest = {
                createdBooking = null
                onGoToMyBookings()
            },
            icon = {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(MintLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = EmeraldDark,
                        modifier = Modifier.size(32.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "تم إرسال طلب الحجز بنجاح!",
                    style = MaterialTheme.typography.headlineSmall
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "تم إرسال طلبك إلى ${nurse.nameAr} وهو الآن بانتظار تأكيد الممرض في لوحة التحكم.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "الخدمة: ${parts.getOrNull(1).orEmpty()}",
                        style = MaterialTheme.typography.labelLarge,
                        color = EmeraldDark
                    )
                    Text(
                        text = "الموعد: ${parts.getOrNull(2).orEmpty()}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "رقم الطلب التجريبي: ${parts.getOrNull(0).orEmpty()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        createdBooking = null
                        onGoToMyBookings()
                    },
                    modifier = Modifier.testTag("dialog_view_bookings_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)
                ) {
                    Text("عرض مواعيدي")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        createdBooking = null
                        onReturnHome()
                    }
                ) {
                    Text("العودة للرئيسية")
                }
            }
        )
    }
}

@Composable
private fun CostLineItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
    }
}
