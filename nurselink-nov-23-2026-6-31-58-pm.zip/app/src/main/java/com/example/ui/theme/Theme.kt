package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = EmeraldDark,
    onPrimary = PureWhite,
    primaryContainer = MintLight,
    onPrimaryContainer = EmeraldDeep,
    secondary = EmeraldVibrant,
    onSecondary = PureWhite,
    secondaryContainer = MintSoft,
    onSecondaryContainer = EmeraldDark,
    tertiary = TealClinical,
    onTertiary = PureWhite,
    tertiaryContainer = TealSoft,
    onTertiaryContainer = TealClinical,
    background = MintWash,
    onBackground = TextPrimary,
    surface = PureWhite,
    onSurface = TextPrimary,
    surfaceVariant = MintSoft,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    outlineVariant = MintLight,
    error = StatusDeclinedFg,
    onError = PureWhite,
    errorContainer = StatusDeclinedBg,
    onErrorContainer = StatusDeclinedFg
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkEmeraldPrimary,
    onPrimary = EmeraldDeep,
    primaryContainer = DarkEmeraldContainer,
    onPrimaryContainer = MintLight,
    secondary = SageAccent,
    onSecondary = EmeraldDeep,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = MintLight,
    tertiary = TealClinical,
    onTertiary = PureWhite,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkEmeraldContainer,
    error = StatusDeclinedFg,
    onError = PureWhite
)

val NurseLinkShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NurseLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = NurseLinkTypography,
            shapes = NurseLinkShapes,
            content = content
        )
    }
}
