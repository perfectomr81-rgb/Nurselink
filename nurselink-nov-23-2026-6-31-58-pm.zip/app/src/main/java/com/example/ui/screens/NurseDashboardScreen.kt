package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PendingActions
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.BookingRequest
import com.example.model.BookingStatus
import com.example.model.NurseProfile
import com.example.ui.components.BookingStatusPill
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.NurseAvatar
import com.example.ui.components.PricePill
import com.example.ui.components.RoleSwitchChip
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVibrant
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintSoft
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.StatusDeclinedFg
import com.example.ui.theme.StatusPendingFg

private enum class NurseRequestFilter(val labelAr: String) {
    ALL("الكل"),
    PENDING("بانتظار الرد"),
    CONFIRMED("مؤكدة"),
    OTHER("أخرى")
}

@Composable
fun NurseDashboardScreen(
    activeNurse: NurseProfile?,
    allNurses: List<NurseProfile>,
    bookings: List<BookingRequest>,
    onSelectActiveNurse: (String) -> Unit,
    onToggleAvailability: () -> Unit,
    onAcceptBooking: (String) -> Unit,
    onDeclineBooking: (String) -> Unit,
    onCompleteBooking: (String) -> Unit,
    onSwitchRole: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by rememberSaveable { mutableStateOf(NurseRequestFilter.ALL) }
    var nurseMenuExpanded by remember { mutableStateOf(false) }

    val pendingCount = bookings.count { it.status == BookingStatus.PENDING }
    val confirmedCount = bookings.count { it.status == BookingStatus.CONFIRMED }
    val estimatedSar = bookings
        .filter { it.status == BookingStatus.CONFIRMED || it.status == BookingStatus.COMPLETED }
        .sumOf { it.totalPriceSar }

    val filteredBookings = bookings.filter { booking ->
        when (selectedFilter) {
            NurseRequestFilter.ALL -> true
            NurseRequestFilter.PENDING -> booking.status == BookingStatus.PENDING
            NurseRequestFilter.CONFIRMED -> booking.status == BookingStatus.CONFIRMED
            NurseRequestFilter.OTHER ->
                booking.status == BookingStatus.COMPLETED ||
                    booking.status == BookingStatus.DECLINED ||
                    booking.status == BookingStatus.CANCELLED
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Emerald Nurse Dashboard Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(EmeraldDeep, EmeraldDark)))
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "لوحة تحكم الممرض",
                                style = MaterialTheme.typography.headlineSmall,
                                color = PureWhite
                            )
                            Text(
                                text = "إدارة الطلبات الواردة والمواعيد",
                                style = MaterialTheme.typography.bodySmall,
                                color = MintLight
                            )
                        }

                        RoleSwitchChip(
                            currentRoleLabel = stringResource(R.string.switch_role),
                            onSwitchRole = onSwitchRole
                        )
                    }

                    if (activeNurse != null) {
                        Surface(
                            shape = MaterialTheme.shapes.large,
                            color = PureWhite.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.24f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    NurseAvatar(nurse = activeNurse, size = 52.dp)
                                    Box(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable { nurseMenuExpanded = true }
                                                .padding(vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Column(modifier = Modifier.weight(1f, fill = false)) {
                                                Text(
                                                    text = activeNurse.nameAr,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    color = PureWhite
                                                )
                                                Text(
                                                    text = "${activeNurse.titleAr} • تبديل الحساب التجريبي",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MintLight
                                                )
                                            }
                                            Icon(
                                                imageVector = Icons.Rounded.ExpandMore,
                                                contentDescription = "تبديل ملف الممرض",
                                                tint = PureWhite
                                            )
                                        }

                                        DropdownMenu(
                                            expanded = nurseMenuExpanded,
                                            onDismissRequest = { nurseMenuExpanded = false }
                                        ) {
                                            allNurses.forEach { nurse ->
                                                DropdownMenuItem(
                                                    text = {
                                                        Text(
                                                            text = "${nurse.nameAr} (${nurse.cityAr})",
                                                            fontWeight = if (nurse.id == activeNurse.id) FontWeight.Bold else FontWeight.Normal
                                                        )
                                                    },
                                                    onClick = {
                                                        nurseMenuExpanded = false
                                                        onSelectActiveNurse(nurse.id)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = PureWhite.copy(alpha = 0.14f)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (activeNurse.isAvailableToday) "متاح لاستقبال طلبات اليوم" else "غير متاح حالياً",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = PureWhite
                                        )
                                        Switch(
                                            checked = activeNurse.isAvailableToday,
                                            onCheckedChange = { onToggleAvailability() },
                                            modifier = Modifier.testTag("nurse_availability_switch"),
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = EmeraldDeep,
                                                checkedTrackColor = MintLight
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // KPI Metrics Grid
        item {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardKpiCard(
                        icon = Icons.Rounded.PendingActions,
                        title = "بانتظار الموافقة",
                        value = "$pendingCount طلب",
                        accent = StatusPendingFg,
                        modifier = Modifier.weight(1f)
                    )
                    DashboardKpiCard(
                        icon = Icons.Rounded.CheckCircle,
                        title = "مواعيد مؤكدة",
                        value = "$confirmedCount موعد",
                        accent = StatusConfirmedFg,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardKpiCard(
                        icon = Icons.Rounded.TaskAlt,
                        title = "إجمالي الخدمات",
                        value = "${activeNurse?.services?.size ?: 0} خدمة",
                        accent = EmeraldDark,
                        modifier = Modifier.weight(1f)
                    )
                    DashboardKpiCard(
                        icon = Icons.Rounded.Payments,
                        title = "دخل تقديري تجريبي",
                        value = "$estimatedSar ر.س",
                        accent = EmeraldVibrant,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Incoming Requests Section Header & Filters
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "طلبات الحجز الواردة (${bookings.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(NurseRequestFilter.entries) { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter.labelAr) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldDark,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                }
            }
        }

        if (filteredBookings.isEmpty()) {
            item {
                Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                    EmptyStateCard(
                        icon = Icons.Rounded.Inbox,
                        title = "لا توجد طلبات في هذا القسم حالياً",
                        subtitle = "عند قيام مريض بطلب حجز جديد لخدماتك سيظهر هنا فوراً لإدارته."
                    )
                }
            }
        } else {
            items(filteredBookings, key = { it.id }) { request ->
                IncomingRequestCard(
                    request = request,
                    onAccept = { onAcceptBooking(request.id) },
                    onDecline = { onDeclineBooking(request.id) },
                    onComplete = { onCompleteBooking(request.id) },
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun DashboardKpiCard(
    icon: ImageVector,
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun IncomingRequestCard(
    request: BookingRequest,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("nurse_request_card_${request.id}"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = request.serviceTitleAr,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "وصل الطلب ${request.createdAtLabelAr}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                BookingStatusPill(status = request.status)
            }

            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MintSoft
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "المستفيد: ${request.patientNameAr}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CalendarMonth,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = request.dateLabelAr,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Schedule,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = request.timeSlotAr,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = request.patientDistrictAr,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            if (request.notesAr.isNotBlank()) {
                Text(
                    text = "ملاحظات الزيارة: ${request.notesAr}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PricePill(priceSar = request.totalPriceSar, prefix = "الإجمالي")

                when (request.status) {
                    BookingStatus.PENDING -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onDecline,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("decline_request_${request.id}"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, StatusDeclinedFg.copy(alpha = 0.5f))
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = null,
                                    tint = StatusDeclinedFg,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("رفض", color = StatusDeclinedFg)
                            }
                            Button(
                                onClick = onAccept,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("accept_request_${request.id}"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldDark,
                                    contentColor = PureWhite
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("قبول الطلب")
                            }
                        }
                    }

                    BookingStatus.CONFIRMED -> {
                        Button(
                            onClick = onComplete,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("complete_request_${request.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldVibrant,
                                contentColor = PureWhite
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DoneAll,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تحديد كمكتملة")
                        }
                    }

                    else -> Unit
                }
            }
        }
    }
}
