package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core NurseLink Healthcare Palette (Dark Green, Light Green, White)
val EmeraldDark = Color(0xFF0A5C40)
val EmeraldDeep = Color(0xFF06402C)
val EmeraldVibrant = Color(0xFF15805B)
val MintLight = Color(0xFFD8F5E8)
val MintSoft = Color(0xFFEBF9F2)
val MintWash = Color(0xFFF5FBF8)
val SageAccent = Color(0xFF34B37E)
val TealClinical = Color(0xFF0E7490)
val TealSoft = Color(0xFFE0F4F8)

val PureWhite = Color(0xFFFFFFFF)
val CardBorder = Color(0xFFD3E7DC)
val TextPrimary = Color(0xFF0D261D)
val TextSecondary = Color(0xFF47665A)
val TextMuted = Color(0xFF708C80)

// Status Colors
val StatusConfirmedBg = Color(0xFFDCFCE7)
val StatusConfirmedFg = Color(0xFF0F6E47)
val StatusPendingBg = Color(0xFFFEF3C7)
val StatusPendingFg = Color(0xFFB45309)
val StatusCompletedBg = Color(0xFFE0F2FE)
val StatusCompletedFg = Color(0xFF0369A1)
val StatusDeclinedBg = Color(0xFFFEE2E2)
val StatusDeclinedFg = Color(0xFFB91C1C)

// Dark Theme Tokens
val DarkBackground = Color(0xFF071711)
val DarkSurface = Color(0xFF0D231A)
val DarkSurfaceVariant = Color(0xFF153427)
val DarkEmeraldPrimary = Color(0xFF5EE0A8)
val DarkEmeraldContainer = Color(0xFF0E4D36)
val DarkTextPrimary = Color(0xFFEAF7F1)
val DarkTextSecondary = Color(0xFFA7C7B8)
