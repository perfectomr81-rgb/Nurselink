package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.WorkHistory
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.NurseProfile
import com.example.model.ServiceCategory
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.NurseAvatar
import com.example.ui.components.PricePill
import com.example.ui.components.RatingSummaryPill
import com.example.ui.components.RoleSwitchChip
import com.example.ui.components.ServiceCategoryChip
import com.example.ui.components.VerifiedBadge
import com.example.ui.components.icon
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVibrant
import com.example.ui.theme.MintLight
import com.example.ui.theme.MintSoft
import com.example.ui.theme.PureWhite
import com.example.viewmodel.NurseLinkUiState

private data class FeaturedServiceBanner(
    val category: ServiceCategory,
    val titleAr: String,
    val subtitleAr: String,
    val minPriceSar: Int
)

private val featuredServiceBanners = listOf(
    FeaturedServiceBanner(ServiceCategory.ELDERLY_CARE, "رعاية كبار السن", "متابعة يومية وأدوية", 180),
    FeaturedServiceBanner(ServiceCategory.INJECTIONS_IV, "حقن ومحاليل وريدية", "إجراء آمن بالمنزل", 85),
    FeaturedServiceBanner(ServiceCategory.WOUND_CARE, "تضميد وتعقيم الجروح", "عناية معقمة دقيقة", 140),
    FeaturedServiceBanner(ServiceCategory.POST_SURGERY, "ما بعد العمليات", "تأهيل ومتابعة الجراحة", 150),
    FeaturedServiceBanner(ServiceCategory.HOME_CHECKUP, "فحوصات منزلية", "ضغط وسكر وعينات", 95)
)

@Composable
fun PatientHomeScreen(
    uiState: NurseLinkUiState,
    onSearchQueryChange: (String) -> Unit,
    onSelectCategory: (ServiceCategory) -> Unit,
    onToggleAvailableToday: () -> Unit,
    onOpenNurseProfile: (String) -> Unit,
    onBookNurse: (String) -> Unit,
    onSwitchRole: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWide = maxWidth >= 680.dp

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Hero Emerald Header with Search Bar
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(listOf(EmeraldDeep, EmeraldDark))
                        )
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "أهلاً بك في نيرس لينك",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = PureWhite
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.LocationOn,
                                        contentDescription = null,
                                        tint = MintLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "رعاية تمريضية منزلية • بيانات تجريبية",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MintLight
                                    )
                                }
                            }

                            RoleSwitchChip(
                                currentRoleLabel = stringResource(R.string.switch_role),
                                onSwitchRole = onSwitchRole
                            )
                        }

                        // Search Bar
                        OutlinedTextField(
                            value = uiState.searchQuery,
                            onValueChange = onSearchQueryChange,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("patient_search_input"),
                            placeholder = {
                                Text(
                                    text = stringResource(R.string.search_nurses_placeholder),
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = "بحث",
                                    tint = EmeraldDark
                                )
                            },
                            trailingIcon = {
                                if (uiState.searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { onSearchQueryChange("") },
                                        modifier = Modifier.testTag("clear_search_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "مسح البحث",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = PureWhite,
                                unfocusedContainerColor = PureWhite,
                                focusedBorderColor = MintLight,
                                unfocusedBorderColor = PureWhite.copy(alpha = 0.6f)
                            )
                        )
                    }
                }
            }

            // Nursing Services Showcase Section
            item {
                Column(
                    modifier = Modifier.padding(top = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الخدمات التمريضية والأسعار",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "أسعار شفافة",
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldVibrant,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(featuredServiceBanners, key = { it.category.name }) { item ->
                            val isSelected = uiState.selectedCategory == item.category
                            ServiceHighlightCard(
                                banner = item,
                                selected = isSelected,
                                onClick = {
                                    onSelectCategory(
                                        if (isSelected) ServiceCategory.ALL else item.category
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // Category Chips & Availability Filter
            item {
                Column(
                    modifier = Modifier.padding(top = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ServiceCategory.entries, key = { it.name }) { category ->
                            ServiceCategoryChip(
                                category = category,
                                selected = uiState.selectedCategory == category,
                                onClick = { onSelectCategory(category) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الممرضون المتاحون (${uiState.filteredNurses.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        FilterChip(
                            selected = uiState.onlyAvailableToday,
                            onClick = onToggleAvailableToday,
                            modifier = Modifier.testTag("filter_available_today"),
                            label = {
                                Text(
                                    text = "متاح اليوم فقط",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.EventAvailable,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                selectedLeadingIconColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }

            // Empty State or Nurse Cards
            if (uiState.filteredNurses.isEmpty()) {
                item {
                    Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                        EmptyStateCard(
                            icon = Icons.Rounded.SearchOff,
                            title = "لم يتم العثور على ممرضين مطابقين",
                            subtitle = "جرّب تعديل كلمات البحث أو اختيار تصنيف آخر للخدمات التمريضية.",
                            action = {
                                OutlinedButton(
                                    onClick = {
                                        onSearchQueryChange("")
                                        onSelectCategory(ServiceCategory.ALL)
                                        if (uiState.onlyAvailableToday) onToggleAvailableToday()
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("إعادة ضبط الفلاتر")
                                }
                            }
                        )
                    }
                }
            } else if (isWide) {
                val rows = uiState.filteredNurses.chunked(2)
                items(rows, key = { row -> row.joinToString("_") { it.id } }) { pair ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { nurse ->
                            NurseDirectoryCard(
                                nurse = nurse,
                                onViewProfile = { onOpenNurseProfile(nurse.id) },
                                onBookNow = { onBookNurse(nurse.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            } else {
                items(uiState.filteredNurses, key = { it.id }) { nurse ->
                    NurseDirectoryCard(
                        nurse = nurse,
                        onViewProfile = { onOpenNurseProfile(nurse.id) },
                        onBookNow = { onBookNurse(nurse.id) },
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ServiceHighlightCard(
    banner: FeaturedServiceBanner,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .width(176.dp)
            .clip(MaterialTheme.shapes.large)
            .clickable(onClick = onClick)
            .testTag("featured_service_${banner.category.name.lowercase()}"),
        shape = MaterialTheme.shapes.large,
        color = if (selected) EmeraldDark else PureWhite,
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) EmeraldDark else MaterialTheme.colorScheme.outline
        ),
        shadowElevation = if (selected) 4.dp else 1.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (selected) PureWhite.copy(alpha = 0.18f) else MintSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = banner.category.icon(),
                        contentDescription = banner.titleAr,
                        tint = if (selected) MintLight else EmeraldDark,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (selected) MintLight else MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "من ${banner.minPriceSar} ر.س",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldDeep,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = banner.titleAr,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (selected) PureWhite else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = banner.subtitleAr,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (selected) MintLight else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun NurseDirectoryCard(
    nurse: NurseProfile,
    onViewProfile: () -> Unit,
    onBookNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .clickable(onClick = onViewProfile)
            .testTag("nurse_card_${nurse.id}"),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                NurseAvatar(nurse = nurse, size = 64.dp)

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = nurse.nameAr,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (nurse.isVerified) {
                            VerifiedBadge(compact = true)
                        }
                    }

                    Text(
                        text = nurse.specialtyAr,
                        style = MaterialTheme.typography.bodyMedium,
                        color = EmeraldVibrant,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        RatingSummaryPill(
                            rating = nurse.rating,
                            reviewsCount = nurse.reviewsCount
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WorkHistory,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${nurse.experienceYears} سنوات خبرة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Location + Availability + Starting Price Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "${nurse.cityAr} • ${nurse.neighborhoodAr}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                AvailabilityBadge(isAvailable = nurse.isAvailableToday)
            }

            // Preview of Offered Services & Prices
            val activeServices = nurse.services.filter { it.isActive }.take(2)
            if (activeServices.isNotEmpty()) {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MintSoft
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        activeServices.forEach { service ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• ${service.titleAr}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${service.priceSar} ر.س",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = EmeraldDark,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PricePill(
                    priceSar = nurse.startingPriceSar,
                    prefix = "تبدأ من"
                )
                Spacer(modifier = Modifier.weight(1f))
                OutlinedButton(
                    onClick = onViewProfile,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("view_profile_button_${nurse.id}"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, EmeraldDark)
                ) {
                    Text(
                        text = stringResource(R.string.view_profile),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                Button(
                    onClick = onBookNow,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("book_now_button_${nurse.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldDark,
                        contentColor = PureWhite
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CalendarMonth,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.book_now),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
